from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask.cli import with_appcontext
import click
import os

app = Flask(__name__)
MYSQL_USER = os.environ.get("MYSQL_USER")
MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD")
MYSQL_DATABASE = os.environ.get("MYSQL_DATABASE")
MYSQL_HOST = os.environ.get("MYSQL_HOST", "db")
SECRET_KEY = os.environ.get("SECRET_KEY")
MANAGER_INITIAL_PASSWORD = os.environ.get("MANAGER_INITIAL_PASSWORD")
FLAG = os.environ.get("FLAG")

app.config['SESSION_COOKIE_HTTPONLY'] = False
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DATABASE}"

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)  # 'employee' or 'manager'

class TimeCard(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    remarks = db.Column(db.String(500))
    approved = db.Column(db.Boolean, default=False)
    cancel_requested = db.Column(db.Boolean, default=False)  # 取り消し申請

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.password == password:
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('ログインできませんでした', 'error')
    return render_template('login.html')

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'employee':
        timecards = TimeCard.query.filter_by(user_id=current_user.id).all()
        return render_template('employee_dashboard.html.j2', timecards=timecards)
    elif current_user.role == 'manager':
        timecards = TimeCard.query.all()
        return render_template('manager_dashboard.html.j2', timecards=timecards, flag=FLAG)

@app.route('/submit_timecard', methods=['POST'])
@login_required
def submit_timecard():
    if current_user.role == 'employee':
        date = request.form.get('date')
        start_time = request.form.get('start_time')
        end_time = request.form.get('end_time')
        remarks = request.form.get('remarks', '')  # 任意項目なのでデフォルト空文字

        # 必須項目のバリデーション
        if not date or not start_time or not end_time:
            flash('日付、開始時刻、終了時刻はすべて入力してください。', 'error')
            return redirect(url_for('dashboard'))

        try:
            timecard = TimeCard(
                user_id=current_user.id,
                date=date,
                start_time=start_time,
                end_time=end_time,
                remarks=remarks
            )
            db.session.add(timecard)
            db.session.commit()
            flash('タイムカードを提出しました。', 'success')
        except Exception as e:
            db.session.rollback()
            flash('タイムカードの登録中にエラーが発生しました。', 'error')
        return redirect(url_for('dashboard'))


@app.route('/cancel_timecard/<int:timecard_id>', methods=['POST'])
@login_required
def cancel_timecard(timecard_id):
    timecard = TimeCard.query.get(timecard_id)
    if not timecard or timecard.user_id != current_user.id:
        flash("不正な操作です", 'error')
        return redirect(url_for('dashboard'))
    if not timecard.approved:
        # 未承認なら即削除
        db.session.delete(timecard)
        db.session.commit()
        flash("タイムカードを取り消しました", 'success')
    else:
        # 承認済みなら取り消し申請
        timecard.cancel_requested = True
        db.session.commit()
        flash("取り消し申請を行いました")
    return redirect(url_for('dashboard'))

@app.route('/approve_timecard/<int:timecard_id>', methods=['POST'])
@login_required
def approve_timecard(timecard_id):
    if current_user.role != 'manager':
        flash("権限がありません", 'error')
        return redirect(url_for('dashboard'))
    timecard = TimeCard.query.get(timecard_id)
    if not timecard:
        flash("タイムカードが見つかりません")
        return redirect(url_for('dashboard'))
    if timecard.cancel_requested:
        # 取り消し申請の承認→削除
        db.session.delete(timecard)
        db.session.commit()
        flash("取り消し申請を承認し、タイムカードを削除しました", 'success')
    elif not timecard.approved:
        # 通常の承認
        timecard.approved = True
        db.session.commit()
        flash("タイムカードを承認しました", 'success')
    return redirect(url_for('dashboard'))

def create_initial_users():
    if not User.query.filter_by(username='manager').first():
        manager = User(username='manager', password=MANAGER_INITIAL_PASSWORD, role='manager')
        db.session.add(manager)
    if not User.query.filter_by(username='user').first():
        user = User(username='user', password='userpass', role='employee')
        db.session.add(user)
    db.session.commit()

@app.route('/logout')
def logout():
    """ログアウト処理: セッションをクリアしてログインページへリダイレクト"""
    logout_user()
    return redirect(url_for('login'))

@click.command('init-db')
@with_appcontext
def init_db_command():
    import time
    time.sleep(15)
    db.create_all()
    create_initial_users()
    click.echo('Initialized the database and created initial users.')

def register_commands(app):
    app.cli.add_command(init_db_command)

register_commands(app)