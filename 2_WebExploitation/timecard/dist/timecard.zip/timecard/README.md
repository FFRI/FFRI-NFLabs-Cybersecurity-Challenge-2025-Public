# 実行手順
1. `docker compose build` を実行します。
2. `docker compose up` を実行して、ホストの`8091/tcp`を`web`Dockerコンテナの`80/tcp`と紐付けつつ、Dockerコンテナを実行します。
    - `8091/tcp`接続を待機する状況になります。
    - 必要に応じてホスト側の紐付けポートを変更します。
3. `http://localhost` にアクセスし、問題へ挑みます。
