require('dotenv').config();
const puppeteer = require('puppeteer');

// sleep関数を定義
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

(async () => {
    // ブラウザを起動
    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();

    // ログインページにアクセス
    await page.goto('http://web/login');

    // ユーザ名とパスワードを入力し、フォームを送信
    await page.type('input[name="username"]', 'manager');
    await page.type('input[name="password"]', process.env.MANAGER_INITIAL_PASSWORD);
    await page.click('button[type="submit"]');

    // ログイン後にページがリダイレクトするのを待つ
    await sleep(5000);

    // ダッシュボードにアクセス
    await page.goto('http://web/dashboard');

    // 承認系ボタン（承認・取り消し申請承認）をすべてクリック
    while (true) {
        // ボタンの数を取得
        const approveCount = await page.evaluate(() => {
            const buttons = Array.from(document.querySelectorAll('button'));
            return buttons.filter(btn => btn.textContent.includes('承認')).length;
        });
        if (approveCount === 0) break;

        // 最初の承認ボタンをクリック
        await page.evaluate(() => {
            const buttons = Array.from(document.querySelectorAll('button'));
            const btn = buttons.find(btn => btn.textContent.includes('承認'));
            if (btn) btn.click();
        });

        await sleep(1000);
        await page.waitForNavigation({waitUntil: 'networkidle0'}).catch(() => {});
        await page.goto('http://web/dashboard');
    }

    // ページの内容を取得してコンソールに出力
    const content = await page.content();
    console.log(content);

    // ブラウザを閉じる
    await browser.close();
})();