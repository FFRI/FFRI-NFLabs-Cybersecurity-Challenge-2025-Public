document.addEventListener('DOMContentLoaded', function () {
    const navLinks = document.querySelectorAll('nav a[href^="#"]');

    navLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);

            if (targetSection) {
                const headerHeight = document.querySelector('header').offsetHeight;
                const targetPosition = targetSection.offsetTop - headerHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    window.addEventListener('scroll', function () {
        const header = document.querySelector('header');
        if (window.scrollY > 100) {
            header.style.background = 'rgba(102, 126, 234, 0.95)';
        } else {
            header.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        }
    });

    const skillCards = document.querySelectorAll('.skill-card');
    const projectCards = document.querySelectorAll('.project-card');

    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    skillCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });

    projectCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('contact-form');
    const websiteUrlGroup = document.getElementById('website-url-group');
    const existingWebsiteRadios = document.querySelectorAll('input[name="existing-website"]');
    const previewButton = document.querySelector('.preview-button');
    const submitButton = document.querySelector('.submit-button');

    existingWebsiteRadios.forEach(radio => {
        radio.addEventListener('change', function () {
            if (this.value === 'yes') {
                websiteUrlGroup.style.display = 'block';
                document.getElementById('website-url').required = true;
            } else {
                websiteUrlGroup.style.display = 'none';
                document.getElementById('website-url').required = false;
                document.getElementById('website-url').value = '';
            }
        });
    });

    function validateForm() {
        const requiredFields = form.querySelectorAll('[required]');
        let isValid = true;

        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.style.borderColor = '#dc3545';
                isValid = false;
            } else {
                field.style.borderColor = '#28a745';
            }
        });

        const emailField = document.getElementById('email');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (emailField.value && !emailRegex.test(emailField.value)) {
            emailField.style.borderColor = '#dc3545';
            isValid = false;
        }

        const phoneField = document.getElementById('phone');
        const phoneRegex = /^[\d\-\(\)\s]+$/;
        if (phoneField.value && !phoneRegex.test(phoneField.value)) {
            phoneField.style.borderColor = '#dc3545';
            isValid = false;
        }

        return isValid;
    }

    const inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('blur', function () {
            if (this.hasAttribute('required') && !this.value.trim()) {
                this.style.borderColor = '#dc3545';
            } else if (this.type === 'email' && this.value) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(this.value)) {
                    this.style.borderColor = '#dc3545';
                } else {
                    this.style.borderColor = '#28a745';
                }
            } else if (this.value) {
                this.style.borderColor = '#28a745';
            }
        });
    });

    previewButton.addEventListener('click', function () {
        if (validateForm()) {
            const formData = new FormData(form);
            let previewText = '=== お問い合わせ内容プレビュー ===\n\n';

            for (let [key, value] of formData.entries()) {
                if (value) {
                    const label = form.querySelector(`[name="${key}"]`).closest('.form-group').querySelector('label');
                    const labelText = label ? label.textContent.replace('*', '').trim() : key;
                    previewText += `${labelText}: ${value}\n`;
                }
            }

            alert(previewText);
        } else {
            alert('必須項目を入力してください。');
        }
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        if (validateForm()) {
            submitButton.disabled = true;
            submitButton.textContent = '送信中...';

            setTimeout(() => {
                alert('お問い合わせありがとうございます！\n\n通常2営業日以内にご返信いたします。');

                form.reset();
                websiteUrlGroup.style.display = 'none';

                submitButton.disabled = false;
                submitButton.textContent = '送信する';

                inputs.forEach(input => {
                    input.style.borderColor = '#ddd';
                });
            }, 2000);
        } else {
            alert('入力内容に誤りがあります。確認してください。');
        }
    });

    const messageField = document.getElementById('message');
    messageField.addEventListener('input', function () {
        const maxLength = 2000;
        const currentLength = this.value.length;

        let counter = this.parentNode.querySelector('.char-counter');
        if (!counter) {
            counter = document.createElement('div');
            counter.className = 'char-counter';
            counter.style.fontSize = '0.8rem';
            counter.style.color = '#666';
            counter.style.marginTop = '0.5rem';
            this.parentNode.appendChild(counter);
        }

        counter.textContent = `${currentLength} / ${maxLength} 文字`;

        if (currentLength > maxLength) {
            counter.style.color = '#dc3545';
        } else {
            counter.style.color = '#666';
        }
    });

    function autoSave() {
        const formData = {};
        inputs.forEach(input => {
            if (input.type === 'radio' || input.type === 'checkbox') {
                if (input.checked) {
                    formData[input.name] = input.value;
                }
            } else {
                formData[input.name] = input.value;
            }
        });

        localStorage.setItem('contactFormData', JSON.stringify(formData));
    }

    inputs.forEach(input => {
        input.addEventListener('input', autoSave);
        input.addEventListener('change', autoSave);
    });

    function restoreFormData() {
        const savedData = localStorage.getItem('contactFormData');
        if (savedData) {
            const formData = JSON.parse(savedData);

            for (let [key, value] of Object.entries(formData)) {
                const field = form.querySelector(`[name="${key}"]`);
                if (field) {
                    if (field.type === 'radio' || field.type === 'checkbox') {
                        if (field.value === value) {
                            field.checked = true;
                        }
                    } else {
                        field.value = value;
                    }
                }
            }

            const existingWebsiteValue = formData['existing-website'];
            if (existingWebsiteValue === 'yes') {
                websiteUrlGroup.style.display = 'block';
            }
        }
    }

    function clearSavedData() {
        localStorage.removeItem('contactFormData');
    }

    restoreFormData();

    form.addEventListener('submit', function (e) {
        if (validateForm()) {
            setTimeout(clearSavedData, 2000);
        }
    });
});
