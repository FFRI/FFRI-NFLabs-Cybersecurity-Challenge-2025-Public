# 開発者向け

## 管理画面認証情報

- ユーザー名: admin
- パスワード: flag{this_is_a_test_flag}
