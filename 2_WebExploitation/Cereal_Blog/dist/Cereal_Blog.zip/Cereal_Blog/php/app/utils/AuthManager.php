<?php

namespace App\Utils;

require_once __DIR__ . '/Jwt.php';
require_once __DIR__ . '/../models/User.php';

class AuthManager
{
    public static function isAuthenticated()
    {
        return self::getCurrentUser() !== null;
    }

    public static function isAdmin()
    {
        $user = self::getCurrentUser();
        return $user && $user['role'] === 'admin';
    }

    public static function getCurrentUser()
    {
        if (!isset($_COOKIE['token'])) {
            return;
        }

        try {
            $decoded = Jwt::decode($_COOKIE['token']);
            if ($decoded->exp < time()) {
                return;
            }
        } catch (\Exception $e) {
            return;
        }

        $user = \App\Models\User::findBy(['username' => $decoded->username, 'uuid' => $decoded->uuid]);

        if (!$user) {
            return;
        }

        return $user;
    }
}
