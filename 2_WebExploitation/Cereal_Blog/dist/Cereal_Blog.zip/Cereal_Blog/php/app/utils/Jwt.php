<?php

namespace App\Utils;

class Jwt
{
    private static $privateKey;
    private static $publicKey;
    private static $algorithm = 'RS256';

    private static function initialize()
    {
        self::$privateKey = file_get_contents(__DIR__ . '/../../secret/private.key');
        self::$publicKey = file_get_contents(__DIR__ . '/../../secret/public.key');
    }

    public static function encode(array $payload): string
    {
        static::initialize();
        return \Firebase\JWT\JWT::encode($payload, self::$privateKey, self::$algorithm);
    }

    public static function decode(string $token): object
    {
        static::initialize();
        return \Firebase\JWT\JWT::decode($token, new \Firebase\JWT\Key(self::$publicKey, self::$algorithm));
    }
}
