<?php

namespace App\Controllers;

require_once __DIR__ . '/../models/Post.php';

class Home extends \Core\Controller
{
    public function index()
    {
        $model = new \App\Models\Post();
        $posts = $model->all();

        $this->view('home/index', [
            'title' => 'hello cereal',
            'posts' => $posts
        ]);
    }
}
