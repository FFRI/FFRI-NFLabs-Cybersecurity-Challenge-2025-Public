<?php

namespace App\Controllers;

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Post.php';
require_once __DIR__ . '/../utils/AuthManager.php';

class User extends \Core\Controller
{
    public function index()
    {
        $users = [];

        if (isset($_GET['q'])) {
            $users = \App\Models\User::search($_GET['q']);
        }
        return $this->view('user/index', ['users' => $users]);
    }

    public function show($user_id)
    {
        $user = \App\Models\User::findBy(['id' => $user_id]);
        if (!$user) {
            return $this->view('user/show', ["msg" => "User $user_id not found"], 404);
        }

        $posts = \App\Models\Post::where(['user_id' => $user_id]);
        return $this->view('user/show', ['user' => $user, 'posts' => $posts]);
    }

    public function showPost($user_id, $post_id)
    {
        $post = \App\Models\Post::findBy(['id' => $post_id, 'user_id' => $user_id]);
        return $this->view('user/post', ['post' => $post]);
    }
}
