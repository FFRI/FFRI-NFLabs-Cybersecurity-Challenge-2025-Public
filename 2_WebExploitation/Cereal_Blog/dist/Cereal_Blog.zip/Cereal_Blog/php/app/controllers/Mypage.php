<?php

namespace App\Controllers;

require_once __DIR__ . '/../models/Post.php';
require_once __DIR__ . '/../utils/AuthManager.php';

class Mypage extends \Core\Controller
{
    public function index()
    {
        $user = \App\Utils\AuthManager::getCurrentUser();
        if ($user === null) {
            $this->redirect('/auth/login', ['error' => 'You must be logged in to access this page']);
        }

        $posts = \App\Models\Post::where(['user_id' => $user['id']]);

        $this->view('mypage/index', ['posts' => $posts]);
    }

    public function postForm()
    {
        if (\App\Utils\AuthManager::getCurrentUser() === null) {
            $this->redirect('/auth/login');
        }

        $this->view('mypage/post', [
            'pageTitle' => 'New Post',
        ]);
    }

    public function post()
    {
        $user = \App\Utils\AuthManager::getCurrentUser();
        if ($user === null) {
            $this->redirect('/auth/login', ['error' => 'You must be logged in to access this page']);
        }

        $title = $_POST['title'] ?? '';
        $content = $_POST['content'] ?? '';
        $filename = $_FILES['filename']['name'] ?? '';

        if (empty($title) || empty($content) || empty($filename)) {
            $this->redirect('/mypage/post', ['error' => 'title and content are required']);
        }

        $mime_type = (new \finfo(FILEINFO_MIME_TYPE))->file($_FILES['filename']['tmp_name']);
        if (!$mime_type || !in_array($mime_type, ALLOWED_IMAGE_TYPES)) {
            $this->redirect('/mypage/post', ['error' => 'JPG, PNG, GIF format images are only allowed']);
        }

        $basename = pathinfo($filename, PATHINFO_FILENAME);
        $extension = pathinfo($filename, PATHINFO_EXTENSION);
        $upload_filename = $basename . '_' . bin2hex(random_bytes(16)) . '.' . $extension;

        $upload_file = UPLOAD_DIR . $upload_filename;
        move_uploaded_file($_FILES['filename']['tmp_name'], $upload_file);

        $post = new \App\Models\Post([
            'user_id' => $user['id'],
            'title' => $title,
            'text' => $content,
            'filename' => $upload_filename
        ]);
        $post->create();

        $this->redirect('/mypage', ['message' => "{$post->id} post created successfully"]);
    }

    public function editForm($post_id)
    {
        $user = \App\Utils\AuthManager::getCurrentUser();
        if ($user === null) {
            $this->redirect('/auth/login', ['error' => 'You must be logged in to access this page']);
        }

        $post = \App\Models\Post::findBy(['id' => $post_id, 'user_id' => $user['id']]);

        if ($post === null) {
            $this->redirect('/mypage', ['error' => "{$post_id} post not found"]);
        }

        $this->view('mypage/post', [
            'post_id' => $post_id,
            'pageTitle' => 'Edit Post',
            'title' => $post['title'],
            'content' => $post['text'],
            'filename' => $post['filename']
        ]);
    }

    public function edit($post_id)
    {
        $user = \App\Utils\AuthManager::getCurrentUser();
        if ($user === null) {
            $this->redirect('/auth/login', ['error' => 'You must be logged in to access this page']);
        }

        $post = \App\Models\Post::findBy(['id' => $post_id, 'user_id' => $user['id']]);
        if ($post === null) {
            $this->redirect('/mypage', ['error' => "{$post_id} post not found"]);
        }

        $title = $_POST['title'] ?? '';
        $content = $_POST['content'] ?? '';
        $filename = $_FILES['filename']['name'] ?? '';

        if (empty($title) || empty($content)) {
            $this->redirect("/mypage/edit/{$post_id}", ['error' => 'title and content are required']);
        }

        $mime_type = (new \finfo(FILEINFO_MIME_TYPE))->file($_FILES['filename']['tmp_name']);
        if (!$mime_type || !in_array($mime_type, ALLOWED_IMAGE_TYPES)) {
            $this->redirect("/mypage/edit/{$post_id}", ['error' => 'JPG, PNG, GIF format images are only allowed']);
        }

        $existing_image = \App\Models\Post::findImage($user['id'], $post_id, $filename);

        if ($existing_image) {
            $upload_filename = $filename;
        } else {
            $basename = pathinfo($filename, PATHINFO_FILENAME);
            $extension = pathinfo($filename, PATHINFO_EXTENSION);
            $upload_filename = $basename . '_' . bin2hex(random_bytes(16)) . '.' . $extension;
            $upload_file = UPLOAD_DIR . $upload_filename;
            move_uploaded_file($_FILES['filename']['tmp_name'], $upload_file);
        }

        $post = new \App\Models\Post([
            'id' => $post_id,
        ]);


        $post->update([
            'title' => $title,
            'text' => $content,
            'filename' => $upload_filename
        ]);

        $this->redirect('/mypage', ['message' => "$post_id post updated successfully"]);
    }

    public function delete($post_id)
    {
        $user = \App\Utils\AuthManager::getCurrentUser();
        if ($user === null) {
            $this->redirect('/auth/login', ['error' => 'You must be logged in to access this page']);
        }

        $post = \App\Models\Post::findBy(['id' => $post_id, 'user_id' => $user['id']]);
        if ($post === null) {
            $this->redirect('/mypage', ['error' => "{$post_id} post not found"]);
        }

        $filename = $post['filename'];
        if ($filename && file_exists(UPLOAD_DIR . $filename)) {
            unlink(UPLOAD_DIR . $filename);
        }

        $post = new \App\Models\Post([
            'id' => $post_id
        ]);
        $post->delete();

        $this->redirect('/mypage', ['message' => "{$post_id} post deleted successfully"]);
    }
}
