<?php

namespace App\Controllers;

require_once __DIR__ . '/../models/AppSetting.php';

require_once __DIR__ . '/../utils/AuthManager.php';

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Post.php';
require_once __DIR__ . '/../models/AppSetting.php';

class Admin extends \Core\Controller
{
    public function index()
    {
        if (!\App\Utils\AuthManager::isAdmin()) {
            $this->redirect('/', ['error' => 'You are not authorized to access this page']);
        }

        $settings = \App\Models\AppSetting::getSettings();
        $this->view('admin/index', ['settings' => $settings]);
    }

    public function setSettings()
    {
        if (!\App\Utils\AuthManager::isAdmin()) {
            $this->redirect('/', ['error' => 'You are not authorized to access this page']);
        }

        $settings = new \App\Models\CustomSettings($_POST['theme'], $_POST['language'], $_POST['timezone']);
        \App\Models\AppSetting::setSettings($settings);

        $this->redirect('/admin', ['success' => 'Settings updated successfully']);
    }

    public function updateRecord()
    {
        if (!\App\Utils\AuthManager::isAdmin()) {
            $this->redirect('/', ['error' => 'You are not authorized to access this page']);
        }


        $table = $_POST['table'];
        $recordId = $_POST['record_id'];
        $column = $_POST['column'];
        $value = $_POST['value'];

        if (!$table || !$recordId || !$column || !$value) {
            $this->redirect('/admin', ['error' => 'Invalid parameters']);
        }

        try {
            $model = match ($table) {
                'users' => \App\Models\User::class,
                'posts' => \App\Models\Post::class,
                'app_settings' => \App\Models\AppSetting::class,
            };
        } catch (\UnhandledMatchError) {
            $this->redirect('/admin', ['error' => 'Invalid table name']);
        }

        try {
            $model = new $model([
                'id' => $recordId,
            ]);

            if (!$model->isExists()) {
                $this->redirect('/admin', ['error' => 'Record not found']);
            }

            if ($model->update([
                $column => $value,
            ])) {
                $this->redirect('/admin', ['success' => 'Record updated successfully']);
            } else {
                $this->redirect('/admin', ['error' => 'Failed to update record']);
            }
        } catch (\Exception $e) {
            $this->redirect('/admin', ['error' => 'Failed to update record']);
        }
    }
}
