<?php

namespace App\Controllers;

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../utils/Jwt.php';

class Auth extends \Core\Controller
{
    public function loginForm()
    {
        $this->view('auth/login', [
            'title' => 'Login'
        ]);
    }

    public function login()
    {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $user = \App\Models\User::findBy(['username' => $username]);

        if (!($user && password_verify($password, $user['password']))) {
            $this->redirect('/auth/login', ['error' => 'Invalid username or password']);
            return;
        }
        $expires = time() + (60 * 60);

        $token = \App\Utils\Jwt::encode([
            'username' => $user['username'],
            'uuid' => $user['uuid'],
            'iat' => time(),
            'exp' => $expires
        ]);
        $_SESSION['token'] = $token;
        setcookie('token', $token, [
            'expires' => $expires,
            'path' => '/',
            'httponly' => true,
            'secure' => false,
            'samesite' => 'Strict'
        ]);
        $this->redirect('/');
    }

    public function registerForm()
    {
        $this->view('auth/register');
    }

    public function register()
    {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $password_confirm = $_POST['password_confirm'] ?? '';

        if ($password !== $password_confirm) {
            $this->redirect('/auth/register', ['error' => 'Passwords do not match']);
            return;
        }

        if (\App\Models\User::findBy(['username' => $username])) {
            $this->redirect('/auth/register', ['error' => 'This username is already taken']);
            return;
        }

        $user = new \App\Models\User([
            'username' => $username,
            'password' => password_hash($password, PASSWORD_DEFAULT)
        ]);
        $user->create();
        $this->redirect('/auth/login');
    }

    public function logout()
    {
        setcookie('token', '', time() - 3600, '/');
        unset($_SESSION['token']);
        $this->redirect('/');
    }
}
