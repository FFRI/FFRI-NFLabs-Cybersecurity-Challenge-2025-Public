<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Router.php';
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Model.php';

$router = new \Core\Router();

$router->get('/', 'Home@index');
$router->get('/auth/login', 'Auth@loginForm');
$router->post('/auth/login', 'Auth@login');
$router->get('/auth/logout', 'Auth@logout');
$router->get('/auth/register', 'Auth@registerForm');
$router->post('/auth/register', 'Auth@register');

$router->get('/users', 'User@index');
$router->get('/users/{user_id}', 'User@show');
$router->get('/users/{user_id}/posts/{post_id}', 'User@showPost');

$router->get('/mypage', 'Mypage@index');
$router->get('/mypage/post', 'Mypage@postForm');
$router->post('/mypage/post', 'Mypage@post');
$router->get('/mypage/post/{post_id}', 'Mypage@editForm');
$router->post('/mypage/post/{post_id}', 'Mypage@edit');
$router->post('/mypage/post/{post_id}/delete', 'Mypage@delete');

$router->get('/admin', 'Admin@index');
$router->post('/admin/settings', 'Admin@setSettings');
$router->post('/admin/update-record', 'Admin@updateRecord');
