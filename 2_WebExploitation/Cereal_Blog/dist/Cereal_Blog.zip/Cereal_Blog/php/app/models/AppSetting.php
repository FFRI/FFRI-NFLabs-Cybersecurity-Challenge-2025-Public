<?php

namespace App\Models;

use PDO;

class AppSetting extends \Core\Model
{
    public function __construct($data = null)
    {
        $this->table = 'app_settings';
        parent::__construct($data);
    }

    public static function getSettings()
    {
        $db = \Core\Model::init_db();
        $stmt = $db->prepare("SELECT settings FROM app_settings WHERE id = 1");
        $stmt->execute();
        $settings = $stmt->fetch(PDO::FETCH_ASSOC);

        return unserialize($settings['settings']);
    }

    public static function initSettings()
    {
        $db = \Core\Model::init_db();
        $stmt = $db->prepare("INSERT INTO app_settings (settings) VALUES (?)");
        $stmt->execute([serialize(new CustomSettings('light', 'en', 'UTC'))]);
    }

    public static function setSettings($settings)
    {
        $db = \Core\Model::init_db();
        $stmt = $db->prepare("UPDATE app_settings SET settings = ? WHERE id = 1");
        $stmt->execute([serialize($settings)]);
    }
}

class CustomSettings
{
    public $theme;
    public $language;
    public $timezone;

    public function __construct($theme, $language, $timezone)
    {
        $this->theme = $theme;
        $this->language = $language;
        $this->timezone = $timezone;
    }
}
