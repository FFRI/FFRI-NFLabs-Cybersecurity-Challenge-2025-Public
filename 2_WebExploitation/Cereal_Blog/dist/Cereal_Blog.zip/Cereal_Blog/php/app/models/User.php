<?php

namespace App\Models;

use Ramsey\Uuid\Uuid;
use PDO;

class User extends \Core\Model
{
    public $username;
    public $password;
    public $uuid;
    public $role;

    public function __construct($data = null)
    {
        $this->table = 'users';
        parent::__construct($data);
    }

    public static function findBy($where = [])
    {
        $db = \Core\Model::init_db();
        $stmt = $db->prepare("SELECT * FROM users WHERE " . implode(' AND ', array_map(function ($key) {
            return self::sanitize($key) . " = ?";
        }, array_keys($where))));
        $stmt->execute(array_values($where));
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create()
    {
        if (!isset($this->uuid)) {
            $this->uuid = Uuid::uuid4()->toString();
        }

        return parent::create();
    }

    public static function search($query)
    {
        $db = \Core\Model::init_db();
        $stmt = $db->prepare("SELECT * FROM users WHERE username LIKE ?");
        $stmt->execute(["%" . self::sanitize($query) . "%"]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
