<?php

namespace App\Models;

use PDO;

class Post extends \Core\Model
{
    public $user_id;
    public $title;
    public $text;
    public $filename;

    public function __construct($data = null)
    {
        $this->table = 'posts';
        parent::__construct($data);
    }

    public static function where($where = [])
    {
        $db = \Core\Model::init_db();

        $stmt = $db->prepare("SELECT * FROM posts WHERE " . implode(' AND ', array_map(function ($key) {
            return self::sanitize($key) . " = ?";
        }, array_keys($where))));
        $stmt->execute(array_values($where));
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function findImage($user_id, $post_id, $filename)
    {
        $filename = self::sanitize($filename);

        $db = \Core\Model::init_db();
        $stmt = $db->prepare("SELECT * FROM posts WHERE user_id = ? AND id = ? AND filename = '{$filename}'");
        $stmt->execute([$user_id, $post_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function findBy($where = [])
    {
        return self::where($where)[0] ?? null;
    }
}
