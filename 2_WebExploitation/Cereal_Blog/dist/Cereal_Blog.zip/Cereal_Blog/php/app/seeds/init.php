<?php

use Ramsey\Uuid\Uuid;

require_once __DIR__ . '/../../vendor/autoload.php';

require_once __DIR__ . '/../../core/Model.php';
require_once __DIR__ . '/../../config/config.php';

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Post.php';
require_once __DIR__ . '/../models/AppSetting.php';

while (true) {
    try {
        $db = \Core\Model::init_db();
        $db->query('SELECT 1');
        break;
    } catch (\Exception $e) {
        echo "Waiting for database to be ready..." . PHP_EOL;
        sleep(1);
    }
}

$users = [];
$usernames = ['alice', 'bob', 'carol', 'dave', 'eve', 'frank', 'grace', 'heidi', 'ivan', 'judy'];
shuffle($usernames);

foreach ($usernames as $key => $username) {
    $user = new \App\Models\User([
        'username' => $username,
        'password' => password_hash(bin2hex(random_bytes(32)), PASSWORD_BCRYPT),
        'uuid' => Uuid::uuid4()->toString(),
        'role' => $key === 0 ? 'admin' : 'user',
    ]);
    $users[] = ['id' => $user->create(), 'name' => $username];
}

$dummyPosts = [
    ['title' => 'My Cereal Journey', 'text' => 'Join me on my exciting journey exploring different cereals from around the world. From classic corn flakes to exotic grain blends, I\'ve tasted countless varieties and discovered amazing flavors. In this post, I\'ll share my top picks and memorable experiences with unique breakfast cereals that have transformed my morning routine.', 'filename' => 'cereal1.png'],
    ['title' => 'Granola Review', 'text' => 'After extensively testing dozens of popular granola brands over the past month, I\'m excited to share my comprehensive review. I\'ll break down the taste, texture, nutritional value, and price points of each brand. Whether you prefer clusters or loose granola, sweet or savory, this guide will help you find your perfect match.', 'filename' => 'cereal2.png'],
    ['title' => 'Healthy Breakfast Guide', 'text' => 'Making the right cereal choice can set you up for a successful day. This guide explores the key nutritional factors to consider: fiber content, sugar levels, whole grain ingredients, and added vitamins and minerals. Learn how to read labels effectively and discover cereals that offer both great taste and optimal nutrition.', 'filename' => 'cereal3.png'],
    ['title' => 'Cereal History', 'text' => 'The fascinating evolution of breakfast cereals spans over a century of innovation. From the first invented cereals at the Battle Creek Sanitarium to modern-day varieties, this post explores how breakfast cereals have transformed from health foods to beloved breakfast staples, reflecting changing societal needs and tastes.', 'filename' => 'cereal4.png'],
    ['title' => 'Kids Favorites', 'text' => 'Discover which cereals consistently rank at the top of children\'s preferences. Through surveys and taste tests with young participants, we\'ve compiled a comprehensive list of kid-approved cereals. We\'ll also discuss the balance between appealing to children\'s tastes while maintaining reasonable nutritional standards.', 'filename' => 'cereal4.png'],
    ['title' => 'Organic Options', 'text' => 'The organic cereal market has exploded with options in recent years. This detailed guide examines the top organic cereal brands, their ingredient sourcing practices, and what makes them stand out. Learn about certification standards, health benefits, and why these premium options might be worth the extra cost.', 'filename' => 'cereal1.png'],
    ['title' => 'Seasonal Specials', 'text' => 'Each season brings exciting limited-edition cereals to store shelves. From summer berry blends to winter holiday specials, these unique varieties offer novel flavors and experiences. This post catalogs the most anticipated seasonal releases and provides insights on when and where to find these temporary treasures.', 'filename' => 'cereal2.png'],
    ['title' => 'Cereal Recipes', 'text' => 'Transform your favorite cereals into delicious treats and dishes. This collection of innovative recipes includes cereal-crusted French toast, homemade granola bars, and creative desserts. Learn how to incorporate cereals into both sweet and savory dishes, perfect for any time of day.', 'filename' => 'cereal3.png'],
    ['title' => 'Low Sugar Options', 'text' => 'Navigate the world of sugar-conscious cereals with this comprehensive guide. We\'ve analyzed dozens of low-sugar and sugar-free options, comparing taste, texture, and satisfaction levels. Discover how manufacturers are using alternative sweeteners and natural ingredients to create healthier yet delicious choices.', 'filename' => 'cereal4.png'],
    ['title' => 'Premium Cereals', 'text' => 'Explore the luxury segment of the cereal market, where artisanal ingredients and unique flavor combinations create extraordinary breakfast experiences. From small-batch granolas to internationally sourced ancient grains, these premium options offer sophisticated taste profiles and exceptional quality.', 'filename' => 'cereal1.png'],
    ['title' => 'Gluten Free Guide', 'text' => 'Finding delicious gluten-free cereals can be challenging. This guide examines certified gluten-free options, comparing taste, texture, and nutritional content. Learn about alternative grains like quinoa and amaranth, and discover brands that have mastered gluten-free cereal production.', 'filename' => 'cereal2.png'],
    ['title' => 'Cereal Cafes', 'text' => 'A new trend is sweeping major cities: dedicated cereal cafes. These unique establishments offer hundreds of cereal varieties, creative combinations, and specialty milk options. Join us on a tour of the most innovative cereal cafes worldwide, exploring their unique concepts and popular menu items.', 'filename' => 'cereal3.png'],
    ['title' => 'Perfect Pairings', 'text' => 'Elevate your cereal experience with perfectly matched toppings. This guide explores complementary fruits, nuts, seeds, and other additions that enhance both taste and nutrition. Learn about seasonal combinations and how to create balanced breakfast bowls that keep you satisfied throughout the morning.', 'filename' => 'cereal4.png'],
    ['title' => 'Texture Guide', 'text' => 'The texture of cereal plays a crucial role in enjoyment. From extra crunchy to light and crispy, this analysis breaks down different cereal textures and their staying power in milk. Discover how manufacturing processes affect texture and find cereals that match your texture preferences.', 'filename' => 'cereal1.png'],
    ['title' => 'Morning Revolution', 'text' => 'The introduction of ready-to-eat cereals revolutionized breakfast habits worldwide. This historical perspective examines how cereals transformed morning routines, impacted family dynamics, and influenced cultural attitudes toward breakfast across different societies and generations.', 'filename' => 'cereal2.png'],
    ['title' => 'Beauty Benefits', 'text' => 'Certain cereals contain ingredients that can promote healthier skin, hair, and nails. This comprehensive guide explores the beauty-boosting properties of various grains, seeds, and fortified cereals. Learn how to choose cereals that not only taste good but also support your beauty routine from the inside out.', 'filename' => 'cereal3.png'],
    ['title' => 'Storage Tips', 'text' => 'Proper storage is crucial for maintaining cereal freshness and crunch. This detailed guide covers optimal storage conditions, container recommendations, and signs of staleness. Learn expert tips for extending shelf life and maintaining flavor, especially in challenging climates.', 'filename' => 'cereal4.png'],
    ['title' => 'Keto Friendly', 'text' => 'The ketogenic diet doesn\'t mean giving up the comfort of a bowl of cereal. This guide examines the growing market of keto-friendly cereals, analyzing their ingredients, net carb content, and taste satisfaction. Discover innovative low-carb alternatives that fit strict ketogenic requirements.', 'filename' => 'cereal1.png'],
    ['title' => 'New Releases', 'text' => 'Stay updated with the latest cereal innovations hitting store shelves. This comprehensive review covers new product launches, including unique flavor combinations, innovative ingredients, and improved nutritional profiles. Learn about upcoming releases and emerging trends in the cereal industry.', 'filename' => 'cereal2.png'],
    ['title' => 'Milk Alternatives', 'text' => 'The choice of milk can significantly impact your cereal experience. This guide explores various plant-based alternatives, from classic soy and almond to innovative oat and pea milk options. Learn how different milk alternatives complement various cereals and affect overall taste and nutrition.', 'filename' => 'cereal3.png']
];

foreach ($users as $user) {
    $postCount = 2;
    $shuffledPosts = $dummyPosts;
    shuffle($shuffledPosts);

    for ($i = 0; $i < $postCount; $i++) {
        $post = new \App\Models\Post([
            'title' => $shuffledPosts[$i]['title'] . ' by ' . $user['name'],
            'text' => $shuffledPosts[$i]['text'],
            'user_id' => $user['id'],
            'filename' => $shuffledPosts[$i]['filename']
        ]);
        $post->create();
    }
}

\App\Models\AppSetting::initSettings();
