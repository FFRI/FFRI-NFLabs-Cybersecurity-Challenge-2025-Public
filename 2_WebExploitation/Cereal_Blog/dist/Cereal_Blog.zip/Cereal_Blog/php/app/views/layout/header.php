<?php require_once __DIR__ . '/../../utils/AuthManager.php'; ?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cereal Blog<?php if (isset($title)) echo ' | ' . $title; ?></title>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="/">Cereal Blog</a>
            <div class="navbar-nav">
                <a class="nav-link" href="/users">Users</a>
                <?php if (\App\Utils\AuthManager::isAdmin()): ?>
                    <a class="nav-link" href="/admin">Admin</a>
                <?php endif; ?>
                <?php if (\App\Utils\AuthManager::isAuthenticated()): ?>
                    <a class="nav-link" href="/mypage">Mypage</a>
                    <a class="nav-link" href="/auth/logout">Logout</a>
                <?php else: ?>
                    <a class="nav-link" href="/auth/login">Login</a>
                    <a class="nav-link" href="/auth/register">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
