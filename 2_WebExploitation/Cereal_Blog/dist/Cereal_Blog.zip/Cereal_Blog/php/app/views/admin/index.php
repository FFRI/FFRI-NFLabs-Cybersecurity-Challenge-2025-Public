<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="container">
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success">
            <?php echo htmlspecialchars($_GET['success']); ?>
        </div>
    <?php endif; ?>
    <h2>AppSettings</h2>
    <form action="/admin/settings" method="post">
        <div class="mb-3">
            <label for="theme" class="form-label">Theme</label>
            <select name="theme" id="theme" class="form-select">
                <option value="light" <?php echo $settings->theme === 'light' ? 'selected' : ''; ?>>light</option>
                <option value="dark" <?php echo $settings->theme === 'dark' ? 'selected' : ''; ?>>dark</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="language" class="form-label">Language</label>
            <select name="language" id="language" class="form-select">
                <option value="en" <?php echo $settings->language === 'en' ? 'selected' : ''; ?>>English</option>
                <option value="ja" <?php echo $settings->language === 'ja' ? 'selected' : ''; ?>>Japanese</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="timezone" class="form-label">Timezone</label>
            <select name="timezone" id="timezone" class="form-select">
                <option value="UTC" <?php echo $settings->timezone === 'UTC' ? 'selected' : ''; ?>>UTC</option>
                <option value="Asia/Tokyo" <?php echo $settings->timezone === 'Asia/Tokyo' ? 'selected' : ''; ?>>Asia/Tokyo</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Save</button>
    </form>

    <h2 class="mt-5">Update Record</h2>
    <form action="/admin/update-record" method="post" class="mb-5">
        <div class="mb-3">
            <label for="table" class="form-label">Table</label>
            <select name="table" id="table" class="form-select" required>
                <option value="">Select table name</option>
                <option value="users">users</option>
                <option value="posts">posts</option>
                <option value="app_settings">app_settings</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="record_id" class="form-label">ID</label>
            <input type="number" class="form-control" id="record_id" name="record_id" required>
        </div>

        <div class="mb-3">
            <label for="column" class="form-label">Column</label>
            <input type="text" class="form-control" id="column" name="column" required>
        </div>

        <div class="mb-3">
            <label for="value" class="form-label">Value</label>
            <input type="text" class="form-control" id="value" name="value" required>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>
