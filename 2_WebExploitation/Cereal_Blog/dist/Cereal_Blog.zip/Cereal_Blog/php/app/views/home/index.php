<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <?php if (isset($_GET['message'])): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($_GET['message']); ?>
                </div>
            <?php endif; ?>
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($_GET['error']); ?>
                </div>
            <?php endif; ?>

            <div class="text-center mb-5">
                <h1 class="display-4 fw-bold">Cereal Blog</h1>
                <p class="lead">Share your favorite cereals with the world!</p>
            </div>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-user-plus fa-3x mb-3 text-primary"></i>
                            <h3>Join Us</h3>
                            <p>Create your account and become part of our cereal-loving community.</p>
                            <a href="/auth/register" class="btn btn-primary">Sign Up Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-edit fa-3x mb-3 text-success"></i>
                            <h3>Share Posts</h3>
                            <p>Write reviews and share your thoughts about your favorite cereals.</p>
                            <a href="/mypage" class="btn btn-success">Start Writing</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-share-alt fa-3x mb-3 text-info"></i>
                            <h3>Connect</h3>
                            <p>Discover new cereals and connect with other cereal enthusiasts.</p>
                            <a href="/users" class="btn btn-info text-white">Explore Posts</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center mt-5">
                <p class="lead">Join thousands of cereal lovers who are already sharing their experiences!</p>
                <a href="/auth/register" class="btn btn-lg btn-primary">Get Started</a>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>
