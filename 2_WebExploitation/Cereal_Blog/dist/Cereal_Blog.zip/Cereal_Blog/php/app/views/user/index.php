<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h1 class="card-title text-center mb-4">Users</h1>

                    <form class="mb-4" method="GET">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control" placeholder="search user" value="<?= isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '' ?>">
                            <button class="btn btn-primary" type="submit">search</button>
                        </div>
                    </form>

                    <?php if (isset($_GET['q'])): ?>
                        <?php if (isset($users) && count($users) > 0): ?>
                            <div class="list-group">
                                <?php foreach ($users as $user): ?>
                                    <li class="list-unstyled">・
                                        <a href="/users/<?php echo $user['id']; ?>" class="text-decoration-none">
                                            @<?php echo htmlspecialchars($user['username']); ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-center text-muted">No users found</p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>
