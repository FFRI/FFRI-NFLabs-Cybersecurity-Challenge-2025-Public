<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div class="container">
    <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
    <form action="/mypage/post<?php if (isset($post_id)) {
                                    echo "/$post_id";
                                } ?>" method="POST" class="mt-4" enctype="multipart/form-data">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        <div class="mb-3">
            <label for="title" class="form-label">title</label>
            <input type="text" class="form-control" id="title" name="title" required value="<?php echo htmlspecialchars($title ?? ''); ?>">
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">content</label>
            <textarea class="form-control" id="content" name="content" rows="10" required><?php echo htmlspecialchars($content ?? ''); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">image</label>
            <input type="file" class="form-control" id="image" name="filename" accept="image/jpeg,image/png,image/gif" <?php echo isset($filename) ? '' : 'required'; ?>>
            <?php if (isset($filename)): ?>
                <div class="mt-2">
                    <p class="mb-2">current image:</p>
                    <img src="/uploads/<?php echo htmlspecialchars($filename); ?>" alt="post image" class="img-fluid mb-2" style="max-width: 200px;">
                </div>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary">post</button>
    </form>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>
