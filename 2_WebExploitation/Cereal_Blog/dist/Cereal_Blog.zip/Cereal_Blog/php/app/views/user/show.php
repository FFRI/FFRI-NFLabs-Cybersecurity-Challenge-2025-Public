<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="header">
                        <?php if (isset($msg)) : ?>
                            <div class="alert alert-danger">
                                <?= htmlspecialchars($msg) ?>
                            </div>
                        <?php else : ?>
                            <h1><?= htmlspecialchars($user['username']) ?>'s profile</h1>
                            <div class="mb-3">
                                <div class="d-flex align-items-center gap-3">
                                    <div>
                                        <span class="text-muted">Username:</span>
                                        <span class="h5 mb-0 ms-1"><?= htmlspecialchars($user['username']) ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if (isset($posts) && count($posts) > 0): ?>
                        <div class="list-group">
                            <div class="posts mt-4">
                                <h2 class="mb-3">Posts</h2>
                                <?php foreach ($posts as $post): ?>
                                    <div class="list-group-item">
                                        <div class="mb-3 d-flex justify-content-center">
                                            <img src="/uploads/<?= htmlspecialchars($post['filename']) ?>" class="img-fluid rounded" style="max-width: 150px;" alt="">
                                        </div>
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h5 class="mb-0"><?php echo htmlspecialchars($post['title']); ?></h5>
                                            <div>
                                                <small class="text-muted me-2">created: <?php echo htmlspecialchars($post['created_at']); ?></small>
                                                <small class="text-muted">updated: <?php echo htmlspecialchars($post['updated_at']); ?></small>
                                            </div>
                                        </div>
                                        <p class="mb-3">
                                            <?php
                                            $content = htmlspecialchars($post['text']);
                                            if (mb_strlen($content) > 100) {
                                                echo mb_substr($content, 0, 100) . '...';
                                            } else {
                                                echo $content;
                                            }
                                            ?>
                                        </p>
                                        <div class="d-flex justify-content-end gap-2">
                                            <a href="/users/<?php echo $user['id']; ?>/posts/<?php echo $post['id']; ?>" class="btn btn-sm btn-primary">detail</a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="text-center text-muted mt-4">No posts</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>
