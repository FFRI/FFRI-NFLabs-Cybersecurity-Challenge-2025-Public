<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2 class="card-title mb-0">Your posts</h2>
                        <a href="/mypage/post" class="btn btn-primary">New post</a>
                    </div>
                    <?php if (isset($_GET['message'])): ?>
                        <div class="alert alert-success">
                            <?php echo htmlspecialchars($_GET['message']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($_GET['error'])): ?>
                        <div class="alert alert-danger">
                            <?php echo htmlspecialchars($_GET['error']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($posts)): ?>
                        <div class="list-group">
                            <?php foreach ($posts as $post): ?>
                                <div class="list-group-item">
                                    <div class="mb-3 d-flex justify-content-center">
                                        <img src="/uploads/<?php echo htmlspecialchars($post['filename']); ?>" alt="post image" class="img-fluid rounded" style="max-width: 150px;">
                                    </div>
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="mb-0"><?php echo htmlspecialchars($post['title']); ?></h5>
                                        <div>
                                            <small class="text-muted me-2">created: <?php echo htmlspecialchars($post['created_at']); ?></small>
                                            <small class="text-muted">updated: <?php echo htmlspecialchars($post['updated_at']); ?></small>
                                        </div>
                                    </div>
                                    <p class="mb-3">
                                        <?php
                                        $content = htmlspecialchars($post['text']);
                                        if (mb_strlen($content) > 100) {
                                            echo mb_substr($content, 0, 100) . '...';
                                        } else {
                                            echo $content;
                                        }
                                        ?>
                                    </p>
                                    <div class="d-flex justify-content-end gap-2">
                                        <a href="/mypage/post/<?php echo $post['id']; ?>" class="btn btn-sm btn-primary">edit</a>
                                        <form action="/mypage/post/<?php echo $post['id']; ?>/delete" method="POST" class="d-inline">
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this post?');">delete</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-center text-muted">No posts</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php require __DIR__ . '/../layout/footer.php'; ?>
