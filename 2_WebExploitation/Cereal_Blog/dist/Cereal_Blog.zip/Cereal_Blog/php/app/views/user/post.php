<?php require __DIR__ . '/../layout/header.php'; ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if (!$post): ?>
                <div class="alert alert-danger">
                    Post not found
                </div>
            <?php else: ?>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="mb-3 d-flex justify-content-center">
                            <img src="/uploads/<?= htmlspecialchars($post['filename']) ?>" class="img-fluid rounded" alt="">
                        </div>
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h1 class="mb-0"><?= htmlspecialchars($post['title']) ?></h1>
                            <div class="text-muted small text-end">
                                <?php if ($post['updated_at'] === $post['created_at']): ?>
                                    created: <?= date('Y/m/d H:i', strtotime($post['created_at'])) ?>
                                <?php else: ?>
                                    created: <?= date('Y/m/d H:i', strtotime($post['created_at'])) ?>
                                    <br>updated: <?= date('Y/m/d H:i', strtotime($post['updated_at'])) ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <p><?= nl2br(htmlspecialchars($post['text'])) ?></p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php require __DIR__ . '/../layout/footer.php'; ?>
