<footer class="footer bg-light fixed-bottom">
    <div class="container">
        <div class="footer-bottom text-center">
            <p>&copy; <?php echo date('Y'); ?> Cereal Blog. All rights reserved.</p>
        </div>
    </div>
</footer>

</body>

</html>
