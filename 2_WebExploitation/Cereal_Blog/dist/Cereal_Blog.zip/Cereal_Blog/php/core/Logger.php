<?php

namespace Core;

class Logger
{
    private static int $logLevel;

    const LEVEL_DEBUG = 0;
    const LEVEL_INFO = 1;
    const LEVEL_WARNING = 2;
    const LEVEL_ERROR = 3;

    public static function initialize($logLevel = self::LEVEL_INFO): void
    {
        self::$logLevel = $logLevel;
    }

    private static function log(int $level, string $message, array $context = []): void
    {
        if ($level < self::$logLevel) {
            return;
        }

        $timestamp = date('Y-m-d H:i:s');
        $levelName = self::getLevelName($level);
        $contextStr = !empty($context) ? json_encode($context) : '';

        $logMessage = sprintf(
            "[%s] %s: %s %s\n",
            $timestamp,
            $levelName,
            $message,
            $contextStr
        );

        error_log($logMessage);
    }

    private static function getLevelName(int $level): string
    {
        return match ($level) {
            self::LEVEL_DEBUG => 'DEBUG',
            self::LEVEL_INFO => 'INFO',
            self::LEVEL_WARNING => 'WARNING',
            self::LEVEL_ERROR => 'ERROR',
            default => 'UNKNOWN'
        };
    }

    public static function debug(string $message, array $context = []): void
    {
        self::log(self::LEVEL_DEBUG, $message, $context);
    }

    public static function info(string $message, array $context = []): void
    {
        self::log(self::LEVEL_INFO, $message, $context);
    }

    public static function warning(string $message, array $context = []): void
    {
        self::log(self::LEVEL_WARNING, $message, $context);
    }

    public static function error(string $message, array $context = []): void
    {
        self::log(self::LEVEL_ERROR, $message, $context);
    }
}
