<?php

namespace Core;

use PDO;
use PDOException;

class Model
{
    protected $db;
    public $table;

    public $id;
    public $created_at;
    public $updated_at;

    public function __construct($data = null)
    {
        $this->db = self::init_db();
        if (isset($data)) {
            foreach ($data as $key => $value) {
                $this->$key = $value;
            }
        }
    }

    public static function init_db()
    {
        try {
            $db = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
                DB_USER,
                DB_PASS,
                [
                    PDO::MYSQL_ATTR_MULTI_STATEMENTS => false,
                ]
            );
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $db;
        } catch (PDOException $e) {
            throw new \Exception("Database connection failed: " . $e->getMessage());
        }
    }

    public function all()
    {
        $stmt = $this->db->query("SELECT * FROM {$this->table}");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create()
    {
        $data = [];

        foreach (get_object_vars($this) as $key => $value) {
            if ($key !== 'db' && $key !== 'table' && $key !== 'id' && $key !== 'created_at' && $key !== 'updated_at' && isset($value)) {
                $data[$key] = $value;
            }
        }

        $fields = implode(', ', array_keys($data));
        $values = implode(', ', array_fill(0, count($data), '?'));

        $stmt = $this->db->prepare("INSERT INTO {$this->table} ({$fields}) VALUES ({$values})");
        $stmt->execute(array_values($data));

        return $this->db->lastInsertId();
    }

    public function update($data)
    {
        $fields = array_map(function ($field) {
            return "{$field} = ?";
        }, array_keys($data));

        $fields = implode(', ', $fields);
        $values = array_values($data);
        $values[] = $this->id;

        $stmt = $this->db->prepare("UPDATE {$this->table} SET {$fields} WHERE id = ?");
        return $stmt->execute($values);
    }

    public function delete()
    {
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE id = {$this->id}");
        return $stmt->execute();
    }

    public function isExists()
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM {$this->table} WHERE id = ?");
        $stmt->execute([$this->id]);
        return $stmt->fetchColumn() > 0;
    }

    public static function sanitize($str)
    {
        $blacklist = ["gtid_subset", "extractvalue", "sleep", "information_schema", "benchmark"];
        return str_ireplace($blacklist, '', $str);
    }
}
