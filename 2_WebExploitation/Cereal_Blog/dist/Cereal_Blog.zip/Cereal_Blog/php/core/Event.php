<?php

namespace Core;

class Event
{
    private $callback;
    private $args;

    public function __construct($callback, $args)
    {
        $this->callback = $callback;
        $this->args = $args;
    }

    public function execute()
    {
        call_user_func_array($this->callback, $this->args);
    }
}
