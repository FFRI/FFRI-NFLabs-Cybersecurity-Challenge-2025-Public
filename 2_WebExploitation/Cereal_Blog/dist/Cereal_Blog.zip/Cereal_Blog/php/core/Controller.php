<?php

namespace Core;

class Controller
{
    protected function view($view, $data = [])
    {
        extract($data);
        $viewFile = __DIR__ . "/../app/views/{$view}.php";

        if (file_exists($viewFile)) {
            require_once $viewFile;
        } else {
            throw new \Exception("View not found: {$view}");
        }
    }

    protected function redirect($path, $query = [])
    {
        $queryString = http_build_query($query);
        $location = $queryString ? "{$path}?{$queryString}" : $path;

        header("Location: {$location}");
        exit;
    }
}
