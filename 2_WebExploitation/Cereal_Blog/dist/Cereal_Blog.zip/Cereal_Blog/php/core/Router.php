<?php

namespace Core;

require_once __DIR__ . '/Event.php';

class Router
{
    private $event;

    private function method($method, $path, $callback)
    {
        $route = $this->matchRoute($method, $path, $callback);
        if (!is_array($route)) {
            return;
        }

        list($controller, $action) = explode('@', $route['callback']);
        $controllerFile = __DIR__ . "/../app/controllers/{$controller}.php";
        $controller = "App\\Controllers\\{$controller}";

        if (!file_exists($controllerFile)) {
            throw new \Exception("Controller not found: {$controller}");
        }

        require_once $controllerFile;
        $controllerInstance = new $controller();
        if (!method_exists($controllerInstance, $action)) {
            throw new \Exception("Action not found: {$action} in {$controller}");
        }

        $this->event = new Event([$controllerInstance, $action], $route['params']);
    }

    public function get($path, $callback)
    {
        $this->method('GET', $path, $callback);
    }

    public function post($path, $callback)
    {
        $this->method('POST', $path, $callback);
    }

    private function matchRoute($method, $path, $callback)
    {
        $actualMethod = $_SERVER['REQUEST_METHOD'];
        $actualPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        if ($actualMethod !== $method) {
            return;
        }

        $pattern = preg_replace('/\{([^}]+)\}/', '(?P<$1>[^/]+)', $path);
        $pattern = str_replace('/', '\/', $pattern);
        $pattern = '/^' . $pattern . '$/';

        $params = [];
        if (!preg_match($pattern, $actualPath, $matches)) {
            return;
        }

        foreach ($matches as $key => $value) {
            if (is_string($key)) {
                $params[$key] = $value;
            }
        }

        return [
            'callback' => $callback,
            'params' => $params
        ];
    }

    private function dispatch()
    {
        try {
            if (is_null($this->event)) {
                header("HTTP/1.1 404 Not Found");
                echo "404 Not Found";
                exit;
            }

            $this->event->execute();
        } catch (\Exception $e) {
            header("HTTP/1.1 500 Internal Server Error");
            if (defined('APP_DEBUG') && APP_DEBUG) {
                echo "Error: " . $e->getMessage();
            } else {
                echo "Internal Server Error";
            }
        }
    }

    public function __destruct()
    {
        $this->dispatch();
    }
}
