#!/bin/sh

mv flag.txt /flag_$(openssl rand -hex 32).txt

php /var/www/html/app/seeds/init.php

nginx -g 'daemon off;' &
. docker-php-entrypoint php-fpm
