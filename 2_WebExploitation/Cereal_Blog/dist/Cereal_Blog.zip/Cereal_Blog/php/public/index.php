<?php

require __DIR__ . '/../vendor/autoload.php';

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../core/Logger.php';

\Core\Logger::initialize(APP_DEBUG ? \Core\Logger::LEVEL_DEBUG : \Core\Logger::LEVEL_INFO);

require_once __DIR__ . '/../app/route.php';
