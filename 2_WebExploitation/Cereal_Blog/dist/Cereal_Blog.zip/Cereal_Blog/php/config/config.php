<?php
define('DB_HOST', 'db');
define('DB_USER', 'root');
define('DB_PASS', 'supersecret');
define('DB_NAME', 'cereal_blog');

define('APP_NAME', 'Cereal Blog');
define('APP_URL', 'http://localhost:8080');

define('APP_DEBUG', getenv('APP_DEBUG') ? true : false);
define('UPLOAD_DIR', __DIR__ . '/../uploads/');

error_reporting(E_ALL);
ini_set('display_errors', 0);

define('ALLOWED_IMAGE_TYPES', [
    'image/jpeg',
    'image/png',
    'image/gif'
]);
