
CREATE TABLE IF NOT EXISTS msgs (
    title TEXT,
    content TEXT
);
