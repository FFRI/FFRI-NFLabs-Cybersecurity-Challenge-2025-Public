package utils

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"fmt"
	"math/rand"
	"strconv"
	"time"
)

func generateKey() []byte {
	delay := rand.Intn(1000)
	time.Sleep(time.Duration(delay) * time.Millisecond)
	var seedTime = time.Now().UnixMilli()
	fmt.Println(strconv.FormatInt(seedTime, 10))
	random := rand.New(rand.NewSource(seedTime))

	key := make([]byte, 16)
	for i := 0; i < 4; i++ {
		val := random.Uint32()
		key[i*4+0] = byte(val >> 24)
		key[i*4+1] = byte(val >> 16)
		key[i*4+2] = byte(val >> 8)
		key[i*4+3] = byte(val)
	}

	return key
}

func pad(src []byte, blockSize int) []byte {
	padding := blockSize - len(src)%blockSize
	padtext := make([]byte, padding)
	for i := range padtext {
		padtext[i] = byte(padding)
	}
	return append(src, padtext...)
}

func EncryptAes(plainText string) string {
	key := generateKey()
	plainBytes := []byte(plainText)

	block, err := aes.NewCipher(key)
	if err != nil {
		panic(err)
	}

	plainBytes = pad(plainBytes, block.BlockSize())

	iv := []byte{0x1a, 0x2b, 0x3c, 0x4d, 0x5e, 0x6f, 0x70, 0x81, 0x92, 0xa3, 0xb4, 0xc5, 0xd6, 0xe7, 0xf8, 0x09}

	mode := cipher.NewCBCEncrypter(block, iv)
	ciphertext := make([]byte, len(plainBytes))
	mode.CryptBlocks(ciphertext, plainBytes)

	return base64.StdEncoding.EncodeToString(ciphertext)
}
