package utils

import (
	"database/sql"
	"fmt"

	_ "github.com/lib/pq"
)

type Message struct {
	Title   string
	Content string
}

// ページに渡すデータ構造体
type PageData struct {
	Keyword  string
	Messages []Message
}

var DB_HOST string = "db"
var DB_USER string = "db_user"
var DB_PASSWORD string = "db_password"

func ConnectDB() (*sql.DB, error) {
	connStr := "host=" + DB_HOST + " port=5400 user=" + DB_USER + " password=" + DB_PASSWORD + " dbname=postgres sslmode=disable"
	fmt.Println(connStr)
	db, err := sql.Open("postgres", connStr)

	if err != nil {
		return nil, err
	}

	return db, err
}

func SearchContent(title string) (PageData, error) {
	var data PageData
	db, err := ConnectDB()
	if err != nil {
		return data, err
	}
	defer db.Close()

	queryStr := "SELECT * from msgs where title ILIKE '%" + title + "%'"
	fmt.Println(queryStr)

	rows, err := db.Query(queryStr)

	if err != nil {
		return data, err
	}
	data.Keyword = title
	defer rows.Close()

	for rows.Next() {
		var msg Message
		err = rows.Scan(&msg.Title, &msg.Content)
		fmt.Printf("%s %s\n", msg.Title, msg.Content)
		data.Messages = append(data.Messages, msg)
	}

	return data, err
}
