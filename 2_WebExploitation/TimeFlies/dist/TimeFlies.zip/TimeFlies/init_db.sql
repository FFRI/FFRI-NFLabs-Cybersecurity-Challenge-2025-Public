ALTER SYSTEM SET port = 5400;
ALTER USER db_user CREATEDB;
GRANT pg_read_server_files TO db_user;
GRANT USAGE ON SCHEMA public TO db_user;
GRANT CREATE ON SCHEMA public TO db_user;
