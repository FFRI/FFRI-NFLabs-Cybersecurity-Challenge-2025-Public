package main

import (
	"encoding/xml"
	"html/template"
	"log"
	"net/http"
	"os"
	"strconv"
	"time"
	"webapp/utils"

	"github.com/gorilla/sessions"
)

var userConfigDir = "/app/"

type User struct {
	Name     string `xml:"Name"`
	Password string `xml:"Password"`
}

var store = sessions.NewCookieStore([]byte("auth-cookie"))

func init() {
	store.Options = &sessions.Options{
		Secure: false,
	}
}
func index(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles("templates/index.html")
	if err != nil {
		http.Error(w, "Error loading index", http.StatusInternalServerError)
		return
	}
	tmpl.Execute(w, nil)
}

func flag(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	username, ok1 := session.Values["username"].(string)
	if auth, ok2 := session.Values["authenticated"].(bool); !ok1 || !ok2 || username != "admin" || !auth {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}

	tmpl, err := template.ParseFiles("templates/flag.html")
	if err != nil {
		http.Error(w, "Error loading page", http.StatusInternalServerError)
		return
	}

	w.Header().Set("AccessTime", strconv.FormatInt(time.Now().UnixMilli(), 10))

	flag := os.Getenv("FLAG")
	flag = utils.EncryptAes(flag)
	tmpl.Execute(w, map[string]string{"Flag": flag})
}

func search(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("AccessTime", strconv.FormatInt(time.Now().UnixMilli(), 10))
	tmpl, err := template.ParseFiles("templates/search.html")
	if err != nil {
		http.Error(w, "Error loading page", http.StatusInternalServerError)
		return
	}

	if r.Method == http.MethodGet {
		tmpl.Execute(w, nil)
	} else if r.Method == http.MethodPost {
		title := r.FormValue("title")
		data, err := utils.SearchContent(title)

		if err != nil {
			http.Error(w, "検索エラー", http.StatusInternalServerError)
			return
		}

		tmpl.Execute(w, data)
	} else {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

func login(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("AccessTime", strconv.FormatInt(time.Now().UnixMilli(), 10))
	if r.Method == http.MethodGet {
		tmpl, err := template.ParseFiles("templates/login.html")
		if err != nil {
			http.Error(w, "Error loading page", http.StatusInternalServerError)
			return
		}

		tmpl.Execute(w, nil)
	} else if r.Method == http.MethodPost {
		username := r.FormValue("username")
		password := r.FormValue("password")
		userConfigPath := userConfigDir + username + ".xml"

		_, err := os.Stat(userConfigPath)
		if err != nil {
			if os.IsNotExist(err) {
				http.Error(w, "User does not exist", http.StatusUnauthorized)
			} else {
				http.Error(w, "Error loading page", http.StatusInternalServerError)
			}
			return
		}

		data, err := os.ReadFile(userConfigPath)
		if err != nil {
			http.Error(w, "Error loading page", http.StatusInternalServerError)
			return
		}

		var user User
		err = xml.Unmarshal(data, &user)

		if password == user.Password {
			session, _ := store.Get(r, "session")
			session.Values["authenticated"] = true
			session.Values["username"] = username
			session.Save(r, w)
			http.Redirect(w, r, "/flag", http.StatusFound)

		} else {
			tmpl, err := template.ParseFiles("templates/login_error.html")
			if err != nil {
				http.Error(w, "Error loading page", http.StatusInternalServerError)
				return
			}
			tmpl.Execute(w, nil)
		}
	} else {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

func main() {
	http.HandleFunc("/", index)
	http.HandleFunc("/login", login)
	http.HandleFunc("/search", search)
	http.HandleFunc("/flag", flag)
	log.Fatal(http.ListenAndServe(":8092", nil))
}
