#include <stdio.h>
#include <stdlib.h>

void __attribute__((section(".flag"))) print_flag() {
    char flag[64] = { 0 };
    FILE* fp = fopen("flag.txt", "r");
    if (!fp) {
        printf("An error occurred while opening the file\n");
        exit(1);
    }
    fread(flag, 1, 64, fp);
    printf("Congratulations! Here's the flag: %s\n", flag);
    exit(0);
}

void greet() {
    char name[16] = { 0 };
    gets(name);
    printf("Hi, %s!\n", name);
}

int main() {
    printf("Tell me your name! : ");
    fflush(stdout);
    greet();
    return 0;
}
