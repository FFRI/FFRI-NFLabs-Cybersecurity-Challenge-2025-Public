#!/bin/bash

set -ex

# 引数チェック
if [ "$#" -ne 1 ]; then
  echo "使い方: $0 <BASE_DIR>"
  echo "例:    $0 /home/user/ctf"
  exit 1
fi

BASE_DIR="$1"
REPO_DIR="$BASE_DIR/working_dir"
COMMITS_FILE="../commit_history.json"

# working_dir 作成・初期化
rm -rf "$REPO_DIR"
mkdir -p "$REPO_DIR"
pushd "$REPO_DIR"

# 検証
if [ ! -f "$COMMITS_FILE" ]; then
  echo "❌ JSONファイル '$COMMITS_FILE' が見つかりません。"
  exit 1
fi

git init

# コミット数取得
TOTAL_COMMITS=$(jq length "$COMMITS_FILE")

for ((i=0; i<TOTAL_COMMITS; i++)); do
  DATE=$(jq -r ".[$i].date" "$COMMITS_FILE")
  COMMENT=$(jq -r ".[$i].comment" "$COMMITS_FILE")
  AUTHOR=$(jq -r ".[$i].author" "$COMMITS_FILE")
  COMMITTER=$(jq -r ".[$i].committer" "$COMMITS_FILE")
  HAS_REMOVE=$(jq "has(\"remove\")" < <(jq ".[$i]" "$COMMITS_FILE"))
  echo "=== コミット $((i+1)) : $COMMENT ==="

  COMMIT_SRC="../$((i+1))"
  if [ -d "$COMMIT_SRC" ]; then
    cp -rf "$COMMIT_SRC"/* . 2>/dev/null || true
  fi

  if [ "$HAS_REMOVE" = "true" ]; then
    REMOVE_COUNT=$(jq ".[$i].remove | length" "$COMMITS_FILE")
    for ((j=0; j<REMOVE_COUNT; j++)); do
      TARGET=$(jq -r ".[$i].remove[$j]" "$COMMITS_FILE")
      rm -f "$TARGET"
      git rm -f "$TARGET" || true
    done
  else
    git add .
  fi

  GIT_AUTHOR_NAME="$AUTHOR" \
  GIT_AUTHOR_EMAIL="$AUTHOR@mirai-itsystems.local" \
  GIT_COMMITTER_NAME="$COMMITTER" \
  GIT_COMMITTER_EMAIL="$COMMITTER@mirai-itsystems.local" \
  GIT_AUTHOR_DATE="$DATE" \
  GIT_COMMITTER_DATE="$DATE" \
  git commit -m "$COMMENT"
done

echo "✅ Gitリポジトリ構築完了：$REPO_DIR"
popd