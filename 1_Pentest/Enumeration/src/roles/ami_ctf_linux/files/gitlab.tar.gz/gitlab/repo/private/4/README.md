# Internal

みらいITシステムズのコーポレートサイト管理リポジトリ

インフラの管理や、チーム内での議論はこちらのリポジトリで行います。

ソースコードは、[publicリポジトリ](http://mirai-itsystems.local:8480/mirai-it-systems/www.mirai-itsystems.local)で管理しています。

## インフラ構成図

![インフラ構成図](./infrastructure.png)

IISサーバーにユーザーが発行されていない人は`develop_common`ユーザーでログインしてください。
