#!/bin/bash

if [[ $# -ne 5 ]]; then
  echo "使い方: $0 <GITLAB_URL> <PROJECT_ID> <USERS_JSON> <ISSUES_JSON> <ADMIN_TOKEN>"
  exit 1
fi

GITLAB_URL="$1"
PROJECT_ID="$2"
USERS_FILE="$3"
ISSUES_FILE="$4"
ADMIN_TOKEN="$5"
echo "$ADMIN_TOKEN"

# bash 用連想配列
declare -A USER_IDS
declare -A USER_TOKENS
declare -A TOKEN_IDS

# -------------------------------
# ユーザー情報取得・トークン発行
# -------------------------------
USER_COUNT=$(jq length "$USERS_FILE")
for ((i = 0; i < USER_COUNT; i++)); do
  GITLAB_USER=$(jq -r ".[$i]" "$USERS_FILE")
  echo "🔍 ユーザー取得: $GITLAB_USER"

  USER_JSON=$(curl -s --header "PRIVATE-TOKEN: $ADMIN_TOKEN" \
    "$GITLAB_URL/api/v4/users?username=$GITLAB_USER")
  USER_ID=$(echo "$USER_JSON" | jq -r '.[0].id')

  if [[ "$USER_ID" == "null" ]]; then
    echo "❌ ユーザー $GITLAB_USER が見つかりません"
    exit 1
  fi

  USER_IDS["$GITLAB_USER"]=$USER_ID

  echo "🔑 トークン発行: $GITLAB_USER"
  TOKEN_JSON=$(curl -s --request POST \
    --header "PRIVATE-TOKEN: $ADMIN_TOKEN" \
    --header "Content-Type: application/json" \
    --data "{\"name\":\"ctf-${GITLAB_USER}\",\"scopes\":[\"api\"],\"expires_at\":\"2025-12-31\"}" \
    "$GITLAB_URL/api/v4/users/${USER_ID}/impersonation_tokens")

  TOKEN=$(echo "$TOKEN_JSON" | jq -r '.token')
  TOKEN_ID=$(echo "$TOKEN_JSON" | jq -r '.id')

  if [[ "$TOKEN" == "null" || -z "$TOKEN" ]]; then
    echo "❌ $GITLAB_USER のトークン作成失敗"
    echo "$TOKEN_JSON"
    exit 1
  fi

  USER_TOKENS["$GITLAB_USER"]=$TOKEN
  TOKEN_IDS["$GITLAB_USER"]=$TOKEN_ID
done

# -------------------------------
# Issue作成とコメント追加
# -------------------------------
ISSUE_COUNT=$(jq length "$ISSUES_FILE")
for ((i = 0; i < ISSUE_COUNT; i++)); do
  TITLE=$(jq -r ".[$i].title" "$ISSUES_FILE")
  DESCRIPTION=$(jq -r ".[$i].description" "$ISSUES_FILE")
  ISSUE_AUTHOR=$(jq -r ".[$i].author // empty" "$ISSUES_FILE")

  if [[ -n "$ISSUE_AUTHOR" && -n "${USER_TOKENS[$ISSUE_AUTHOR]}" ]]; then
    POSTER_TOKEN=${USER_TOKENS[$ISSUE_AUTHOR]}
  else
    POSTER_TOKEN=$ADMIN_TOKEN
  fi

  echo "📌 Issue作成: $TITLE （作成者: ${ISSUE_AUTHOR:-admin})"

  ISSUE_JSON=$(curl -s --request POST "$GITLAB_URL/api/v4/projects/$PROJECT_ID/issues" \
    --header "PRIVATE-TOKEN: $POSTER_TOKEN" \
    --header "Content-Type: application/json" \
    --data "{\"title\":\"$TITLE\", \"description\":\"$DESCRIPTION\"}")

  ISSUE_IID=$(echo "$ISSUE_JSON" | jq -r '.iid')

  COMMENT_COUNT=$(jq ".[$i].comments | length" "$ISSUES_FILE")
  for ((j = 0; j < COMMENT_COUNT; j++)); do
    BODY=$(jq -r ".[$i].comments[$j].body" "$ISSUES_FILE")
    COMMENT_AUTHOR=$(jq -r ".[$i].comments[$j].author" "$ISSUES_FILE")
    COMMENT_TOKEN=${USER_TOKENS[$COMMENT_AUTHOR]}

    echo "  💬 コメント by $COMMENT_AUTHOR: $BODY"

    curl -s --request POST \
      "$GITLAB_URL/api/v4/projects/$PROJECT_ID/issues/$ISSUE_IID/notes" \
      --header "PRIVATE-TOKEN: $COMMENT_TOKEN" \
      --header "Content-Type: application/json" \
      --data "{\"body\":\"$BODY\"}" > /dev/null
  done
done

# -------------------------------
# トークン削除
# -------------------------------
for USER in "${!TOKEN_IDS[@]}"; do
  GITLAB_UID=${USER_IDS[$USER]}
  TID=${TOKEN_IDS[$USER]}
  curl -s --request DELETE \
    --header "PRIVATE-TOKEN: $ADMIN_TOKEN" \
    "$GITLAB_URL/api/v4/users/$GITLAB_UID/impersonation_tokens/$TID" > /dev/null
  echo "🗑️  $USER のトークン削除完了"
done

echo "✅ 全処理完了"